import React from "react";
import "./index.css";
import {Link} from "react-router-dom";
import {useLocation} from "react-router";

const NavigationSidebar = () => {
    const {pathname} = useLocation();
    const paths = pathname.split('/')
    const active = paths[2];
 return (
    <>
    <div className ="list-group">
        <Link to="#" className ="list-group-item list-group-item-action">
        <i className ="fab fa-twitter"></i>
        </Link>


        <Link to="/tuiter/home" class="list-group-item wd-nav-anchor" >
          <i class="fa fa-home"></i>
          <span className="d-none d-xl-block wd-nav-anchor-text" >Home</span>
        </Link>
    </div>


    <div class="d-grid mt-2">
        <a href="tweet.html"
        class="btn btn-primary btn-block rounded-pill">
        Tweet</a>
    </div>
    </>
 );
};
export default NavigationSidebar;