import Assignment6 from "./a6";
import Nav from "../nav";

function Labs() {
    return(
       <div>
            <Nav/>
            <Assignment6/>
       </div>
    );
 }
 export default Labs;