export default [
    {
        topic: 'Web Development',
        avatar_img: "../../images/banner1.jpg",
        handle: "elonmusk",
        userName: 'Elon Musk',
        time: '23h',
        title: 'amzing show about the mission',
        image: '../../images/spaceman.jpg',
        link_title: 'contdown: inspiration4 mission to space',
        content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.',
        comment_number: "4.2k",
        retweet_number: "3.5k",
        like_number: "37.5k",
    },

    {
        topic: 'Web Development',
        avatar_img: "../../images/dog.jpg",
        handle: "mypost",
        userName: 'New York Times',
        time: '23h',
        title: 'amzing show about the mission',
        image: '../../images/booksIMG.jpg',
        link_title: 'contdown: inspiration4 mission to space',
        content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.',
        comment_number: "965",
        retweet_number: "2.4k",
        like_number: "4k",
    },
];
 