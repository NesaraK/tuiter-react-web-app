export default [
    {   avatarIcon: '../../images/java.png',
      userName: 'Java', handle: 'Java', },
    {   avatarIcon: '../../images/Rspace.png',
      userName: 'Relativity Space',
      handle: 'relativityspace', },
    {   avatarIcon: '../../images/Vgal.png',
      userName: 'Virgin Galactic',
      handle: 'virgingalactic', },
    {   avatarIcon: '../../images/NASA.png',
      userName: 'NASA', handle: 'NASA', },
    {   avatarIcon: '../../images/tesla.png',
      userName: 'Tesla', handle: 'Tesla', }, ];