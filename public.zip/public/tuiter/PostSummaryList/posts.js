export default [
    {
        "topic": "Web Development",
        "userName": "ReactJS",
        "time": "2h",
        "image": "../../images/reactlogo.png",
        "title": "React.js is a component based front end library that makes it very easy to build Single Page Applications or SPAs",
       },

    {
        "topic": "Web Development",
        "userName": "JavaScript",
        "time": "1 day",
        "image": "../../images/JavaScript-logo.png",
        "title": "React.js is a component based front end library that makes it very easy to build Single Page Applications or SPAs",
       },

    {
        "topic": "Web Development",
        "userName": "jQuery",
        "time": "last week",
        "image": "../../images/Jquery.png",
        "title": "",
       },

    {
        "topic": "Web Development",
        "userName": "NodeJS",
        "time": "last month",
        "image": "../../images/NodeJS.png",
        "title": "",
       },
    
    
    
    
    
    ]
       